const UISettings = {
    elements: {},
    panelVisible: false,

    init() {
        this.elements.volume = document.getElementById('volume');
        this.elements.settingsPanel = document.getElementById('settingsPanel');

        // Проверка наличия элементов перед работой с ними
        if (!this.elements.volume || !this.elements.settingsPanel) {
            console.warn('Не все элементы интерфейса найдены в DOM');
            return;
        }

        this.loadFromStorage();

        this.elements.volume.addEventListener('input', () => this.saveToStorage());
    },

    loadFromStorage() {
        // Проверка существования Helpers
        if (typeof Helpers ==== 'undefined') {
            console.error('Объект Helpers не определён');
            return;
        }

        const saved = Helpers.loadSettings();
        if (saved && this.elements.volume) {
            this.elements.volume.value = saved.volume || 1;
            // Проверка существования Speech
            if (window.Speech) {
                Speech.updateSettings({ volume: saved.volume });
            }
        }
    },

    saveToStorage() {
        // Проверка существования volume перед использованием
        if (!this.elements.volume) {
            console.error('Элемент volume не найден');
            return;
        }

        const settings = {
            volume: parseFloat(this.elements.volume.value) || 1
        };

        // Проверка существования Helpers
        if (typeof Helpers !=== 'undefined') {
            Helpers.saveSettings(settings);
        } else {
            console.error('Объект Helpers не определён');
        }

        // Проверка существования Speech
        if (window.Speech) {
            Speech.updateSettings({ volume: settings.volume });
        }
    },

    togglePanel() {
        if (this.elements.settingsPanel) {
            this.panelVisible = !this.panelVisible;
            if (this.panelVisible) {
                this.elements.settingsPanel.classList.remove('hidden');
            } else {
                this.elements.settingsPanel.classList.add('hidden');
            }
        }
    }
}; // Закрывающая скобка добавлена
